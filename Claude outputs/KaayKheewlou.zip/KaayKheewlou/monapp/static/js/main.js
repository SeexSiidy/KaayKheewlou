// Kaay Kheewlou — script client (aucune dépendance externe)
document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('.navbar-toggle');
  var links = document.querySelector('.navbar-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      links.classList.toggle('ouvert');
    });
  }

  // Fermer les messages flash automatiquement
  document.querySelectorAll('.message').forEach(function (msg) {
    setTimeout(function () {
      msg.style.transition = 'opacity .5s ease';
      msg.style.opacity = '0';
      setTimeout(function () { msg.remove(); }, 500);
    }, 5000);
  });

  // Boutons +/- de quantité
  document.querySelectorAll('[data-qte-moins]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.querySelector(btn.getAttribute('data-qte-moins'));
      if (input) input.value = Math.max(1, (parseInt(input.value, 10) || 1) - 1);
    });
  });
  document.querySelectorAll('[data-qte-plus]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.querySelector(btn.getAttribute('data-qte-plus'));
      if (input) input.value = (parseInt(input.value, 10) || 1) + 1;
    });
  });

  // Auto-submit des formulaires de mise à jour de quantité du panier
  document.querySelectorAll('.qte-form input[type="number"]').forEach(function (input) {
    input.addEventListener('change', function () {
      input.closest('form').submit();
    });
  });

  // Afficher/masquer le champ adresse selon le mode de réception choisi
  var radiosReception = document.querySelectorAll('input[name="mode_reception"]');
  var blocAdresse = document.querySelector('[data-bloc-adresse]');
  function majAdresse() {
    if (!blocAdresse) return;
    var val = document.querySelector('input[name="mode_reception"]:checked');
    blocAdresse.style.display = (val && val.value === 'livraison') ? 'block' : 'none';
  }
  radiosReception.forEach(function (r) { r.addEventListener('change', majAdresse); });
  majAdresse();
});
