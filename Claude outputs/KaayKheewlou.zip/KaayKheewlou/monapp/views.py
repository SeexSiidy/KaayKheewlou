from decimal import Decimal

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.db.models import Count, F, Q, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse

from .cart import Panier
from .forms import (
    CategorieForm, ConnexionAdminForm, InfosCommandeForm, InscriptionForm,
    NouveauMotDePasseForm, ProduitForm, RecuperationIdentiteForm,
    RechercheCommandeForm,
)
from .models import ArticleCommande, Categorie, Commande, Produit, ProfilClient

SESSION_INFOS_COMMANDE = 'infos_commande'
SESSION_MES_COMMANDES = 'mes_commandes'
SESSION_RESET_USER_ID = 'reset_user_id'


# ---------------------------------------------------------------------------
# Espace client (visiteur)
# ---------------------------------------------------------------------------

def accueil(request):
    produits = Produit.objects.filter(actif=True).select_related('categorie')

    q = request.GET.get('q', '').strip()
    if q:
        produits = produits.filter(Q(nom__icontains=q) | Q(description__icontains=q))

    categorie_slug = request.GET.get('categorie', '').strip()
    if categorie_slug:
        produits = produits.filter(categorie__slug=categorie_slug)

    contexte = {
        'produits': produits,
        'categories': Categorie.objects.all(),
        'q': q,
        'categorie_slug': categorie_slug,
        'produits_promo': Produit.objects.filter(actif=True, en_promo=True)[:6],
    }
    return render(request, 'src/accueil.html', contexte)


def produit_detail(request, slug):
    produit = get_object_or_404(Produit, slug=slug, actif=True)
    suggestions = Produit.objects.filter(actif=True, categorie=produit.categorie).exclude(pk=produit.pk)[:4]
    return render(request, 'src/produit_detail.html', {'produit': produit, 'suggestions': suggestions})


def panier_ajouter(request, produit_id):
    produit = get_object_or_404(Produit, id=produit_id, actif=True)
    panier = Panier(request)
    try:
        quantite = int(request.POST.get('quantite', 1))
    except (TypeError, ValueError):
        quantite = 1
    quantite = max(1, quantite)
    panier.ajouter(produit=produit, quantite=quantite)
    messages.success(request, f"« {produit.nom} » a été ajouté à votre panier.")
    suivant = request.POST.get('suivant') or request.META.get('HTTP_REFERER') or reverse('monapp:accueil')
    return redirect(suivant)


def panier_maj(request, produit_id):
    produit = get_object_or_404(Produit, id=produit_id)
    panier = Panier(request)
    try:
        quantite = int(request.POST.get('quantite', 1))
    except (TypeError, ValueError):
        quantite = 1
    panier.ajouter(produit=produit, quantite=quantite, remplacer=True)
    return redirect('monapp:panier')


def panier_retirer(request, produit_id):
    produit = get_object_or_404(Produit, id=produit_id)
    panier = Panier(request)
    panier.retirer(produit)
    messages.info(request, f"« {produit.nom} » a été retiré de votre panier.")
    return redirect('monapp:panier')


def panier_vue(request):
    panier = Panier(request)
    autres_produits = Produit.objects.filter(actif=True).exclude(
        id__in=[item['produit'].id for item in panier]
    )[:8]
    return render(request, 'src/panier.html', {'panier': panier, 'autres_produits': autres_produits})


def commande_vue(request):
    panier = Panier(request)
    if panier.est_vide():
        messages.warning(request, "Votre panier est vide. Ajoutez des produits avant de commander.")
        return redirect('monapp:accueil')

    if request.method == 'POST':
        form = InfosCommandeForm(request.POST)
        if form.is_valid():
            request.session[SESSION_INFOS_COMMANDE] = form.cleaned_data
            return redirect('monapp:valider_commande')
    else:
        initial = {}
        if request.user.is_authenticated and not request.user.is_staff:
            profil = getattr(request.user, 'profil_client', None)
            initial = {
                'client_nom': request.user.first_name or request.user.username,
                'client_telephone': profil.telephone if profil else '',
                'client_email': request.user.email,
            }
        initial.update(request.session.get(SESSION_INFOS_COMMANDE, {}))
        form = InfosCommandeForm(initial=initial)

    produits_dispo = Produit.objects.filter(actif=True).exclude(
        id__in=[item['produit'].id for item in panier]
    )[:6]

    return render(request, 'src/commande.html', {
        'panier': panier,
        'form': form,
        'produits_dispo': produits_dispo,
    })


def valider_commande_vue(request):
    panier = Panier(request)
    infos = request.session.get(SESSION_INFOS_COMMANDE)
    if panier.est_vide() or not infos:
        messages.warning(request, "Merci de renseigner vos informations de commande avant de valider.")
        return redirect('monapp:commande')

    mode_reception = infos.get('mode_reception', Commande.MODE_RETRAIT)
    frais_livraison = Decimal(settings.FRAIS_LIVRAISON) if mode_reception == Commande.MODE_LIVRAISON else Decimal('0')
    sous_total = panier.get_total()
    total = sous_total + frais_livraison

    if request.method == 'POST':
        mode_paiement = request.POST.get('mode_paiement', Commande.PAIEMENT_LIQUIDE)

        commande = Commande.objects.create(
            utilisateur=request.user if request.user.is_authenticated and not request.user.is_staff else None,
            client_nom=infos.get('client_nom', ''),
            client_telephone=infos.get('client_telephone', ''),
            client_email=infos.get('client_email', ''),
            client_adresse=infos.get('client_adresse', ''),
            mode_reception=mode_reception,
            mode_paiement=mode_paiement,
            note=infos.get('note', ''),
            sous_total=sous_total,
            frais_livraison=frais_livraison,
            total=total,
        )
        for item in panier:
            ArticleCommande.objects.create(
                commande=commande,
                produit=item['produit'],
                nom_produit=item['produit'].nom,
                prix_unitaire=item['prix_unitaire'],
                quantite=item['quantite'],
            )
            produit = item['produit']
            if produit.stock >= item['quantite']:
                produit.stock = F('stock') - item['quantite']
                produit.save(update_fields=['stock'])

        mes_commandes = request.session.get(SESSION_MES_COMMANDES, [])
        mes_commandes.insert(0, commande.numero)
        request.session[SESSION_MES_COMMANDES] = mes_commandes[:20]

        panier.vider()
        request.session.pop(SESSION_INFOS_COMMANDE, None)

        messages.success(request, f"Votre commande {commande.numero} a bien été validée. Merci pour votre confiance !")
        return redirect('monapp:suivi_commande', numero=commande.numero)

    return render(request, 'src/valider_commande.html', {
        'panier': panier,
        'infos': infos,
        'frais_livraison': frais_livraison,
        'sous_total': sous_total,
        'total': total,
        'paiement_choices': Commande.PAIEMENT_CHOICES,
    })


def suivi_commande_vue(request, numero):
    commande = get_object_or_404(Commande, numero=numero)
    etapes = [c for c in Commande.STATUT_CHOICES]
    return render(request, 'src/suivi_commande.html', {'commande': commande, 'etapes': etapes})


def historique_commandes_vue(request):
    numeros = request.session.get(SESSION_MES_COMMANDES, [])
    commandes_qs = Commande.objects.filter(numero__in=numeros)
    if request.user.is_authenticated and not request.user.is_staff:
        commandes_qs = commandes_qs | Commande.objects.filter(utilisateur=request.user)
    commandes = list(commandes_qs.distinct())
    commandes.sort(key=lambda c: c.date_creation, reverse=True)
    return render(request, 'src/historique_commandes.html', {'commandes': commandes})


def recherche_commande_vue(request):
    commande = None
    form = RechercheCommandeForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        try:
            commande = Commande.objects.get(
                numero__iexact=form.cleaned_data['numero'].strip(),
                client_telephone=form.cleaned_data['client_telephone'].strip(),
            )
        except Commande.DoesNotExist:
            messages.error(request, "Aucune commande ne correspond à ces informations.")
    return render(request, 'src/recherche_commande.html', {'form': form, 'commande': commande})


# ---------------------------------------------------------------------------
# Mon compte (client + connexion administrateur unifiée)
# ---------------------------------------------------------------------------

def compte_vue(request):
    if request.user.is_authenticated:
        if request.user.is_staff:
            return render(request, 'src/compte.html', {'compte_admin_connecte': True})
        nb_commandes = Commande.objects.filter(utilisateur=request.user).count()
        return render(request, 'src/compte.html', {
            'nb_commandes': nb_commandes,
            'profil': getattr(request.user, 'profil_client', None),
        })

    connexion_form = ConnexionAdminForm(prefix='connexion')
    inscription_form = InscriptionForm(prefix='inscription')

    if request.method == 'POST' and request.POST.get('action') == 'connexion':
        connexion_form = ConnexionAdminForm(request.POST, prefix='connexion')
        if connexion_form.is_valid():
            user = authenticate(
                request,
                username=connexion_form.cleaned_data['username'],
                password=connexion_form.cleaned_data['password'],
            )
            if user is not None:
                login(request, user)
                if user.is_staff:
                    messages.success(request, "Connexion administrateur réussie.")
                    return redirect('monapp:admin_dashboard')
                messages.success(request, f"Bienvenue, {user.first_name or user.username} !")
                return redirect('monapp:compte')
            connexion_form.add_error(None, "Identifiant ou mot de passe incorrect.")

    elif request.method == 'POST' and request.POST.get('action') == 'inscription':
        inscription_form = InscriptionForm(request.POST, prefix='inscription')
        if inscription_form.is_valid():
            donnees = inscription_form.cleaned_data
            user = User.objects.create_user(
                username=donnees['username'],
                email=donnees['email'],
                password=donnees['password1'],
                first_name=donnees['nom'],
            )
            ProfilClient.objects.create(user=user, telephone=donnees['telephone'])
            login(request, user)
            messages.success(request, f"Votre compte a été créé, bienvenue {user.first_name} !")
            return redirect('monapp:compte')

    return render(request, 'src/compte.html', {
        'connexion_form': connexion_form,
        'inscription_form': inscription_form,
    })


def compte_deconnexion_vue(request):
    logout(request)
    messages.info(request, "Vous avez été déconnecté.")
    return redirect('monapp:accueil')


def compte_mdp_oublie_vue(request):
    form = RecuperationIdentiteForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        try:
            profil = ProfilClient.objects.get(
                telephone=form.cleaned_data['telephone'].strip(),
                user__username__iexact=form.cleaned_data['username'].strip(),
            )
        except ProfilClient.DoesNotExist:
            messages.error(request, "Aucun compte ne correspond à cet identifiant et ce téléphone.")
        else:
            request.session[SESSION_RESET_USER_ID] = profil.user_id
            return redirect('monapp:compte_mdp_nouveau')
    return render(request, 'src/compte_mdp_oublie.html', {'form': form})


def compte_mdp_nouveau_vue(request):
    user_id = request.session.get(SESSION_RESET_USER_ID)
    if not user_id:
        messages.warning(request, "Merci de vérifier d'abord votre identité.")
        return redirect('monapp:compte_mdp_oublie')

    utilisateur = get_object_or_404(User, pk=user_id)
    form = NouveauMotDePasseForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        utilisateur.set_password(form.cleaned_data['password1'])
        utilisateur.save()
        request.session.pop(SESSION_RESET_USER_ID, None)
        messages.success(request, "Votre mot de passe a été réinitialisé. Vous pouvez vous connecter.")
        return redirect('monapp:compte')
    return render(request, 'src/compte_mdp_nouveau.html', {'form': form, 'utilisateur': utilisateur})


# ---------------------------------------------------------------------------
# Espace administrateur (gestion)
# ---------------------------------------------------------------------------

def admin_login_vue(request):
    if request.user.is_authenticated:
        return redirect('monapp:admin_dashboard')

    form = ConnexionAdminForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = authenticate(
            request,
            username=form.cleaned_data['username'],
            password=form.cleaned_data['password'],
        )
        if user is not None and user.is_staff:
            login(request, user)
            return redirect('monapp:admin_dashboard')
        messages.error(request, "Identifiant ou mot de passe incorrect.")
    return render(request, 'src/admin_login.html', {'form': form})


def admin_logout_vue(request):
    logout(request)
    return redirect('monapp:admin_login')


def est_staff(user):
    return user.is_authenticated and user.is_staff


@user_passes_test(est_staff, login_url='monapp:admin_login')
def admin_dashboard_vue(request):
    commandes = Commande.objects.all()
    chiffre_affaires = commandes.exclude(statut=Commande.STATUT_VALIDEE).aggregate(total=Sum('total'))['total'] or 0

    top_produits = (
        ArticleCommande.objects.values('nom_produit')
        .annotate(quantite_totale=Sum('quantite'))
        .order_by('-quantite_totale')[:5]
    )

    commandes_par_statut = commandes.values('statut').annotate(total=Count('id'))
    compteurs = {s: 0 for s, _ in Commande.STATUT_CHOICES}
    for entree in commandes_par_statut:
        compteurs[entree['statut']] = entree['total']
    stats_statuts = [
        {'cle': cle, 'libelle': libelle, 'total': compteurs.get(cle, 0)}
        for cle, libelle in Commande.STATUT_CHOICES
    ]

    contexte = {
        'nb_commandes': commandes.count(),
        'nb_commandes_en_cours': commandes.exclude(statut=Commande.STATUT_TERMINEE).count(),
        'chiffre_affaires': chiffre_affaires,
        'top_produits': top_produits,
        'stats_statuts': stats_statuts,
        'produits_stock_faible': Produit.objects.filter(stock__gt=0, stock__lte=5),
        'produits_rupture': Produit.objects.filter(stock=0),
        'nb_produits': Produit.objects.count(),
        'dernieres_commandes': commandes[:6],
    }
    return render(request, 'src/admin_dashboard.html', contexte)


@user_passes_test(est_staff, login_url='monapp:admin_login')
def admin_produits_vue(request):
    produits = Produit.objects.select_related('categorie').all()
    q = request.GET.get('q', '').strip()
    if q:
        produits = produits.filter(nom__icontains=q)
    return render(request, 'src/admin_produits.html', {'produits': produits, 'q': q})


@user_passes_test(est_staff, login_url='monapp:admin_login')
def admin_produit_form_vue(request, pk=None):
    produit = get_object_or_404(Produit, pk=pk) if pk else None
    form = ProduitForm(request.POST or None, request.FILES or None, instance=produit)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, "Produit enregistré avec succès.")
        return redirect('monapp:admin_produits')
    return render(request, 'src/admin_produit_form.html', {'form': form, 'produit': produit})


@user_passes_test(est_staff, login_url='monapp:admin_login')
def admin_produit_supprimer_vue(request, pk):
    produit = get_object_or_404(Produit, pk=pk)
    if request.method == 'POST':
        produit.delete()
        messages.success(request, "Produit supprimé.")
        return redirect('monapp:admin_produits')
    return render(request, 'src/admin_confirmer_suppression.html', {'objet': produit, 'type_objet': 'produit'})


@user_passes_test(est_staff, login_url='monapp:admin_login')
def admin_categories_vue(request):
    categories = Categorie.objects.annotate(nb_produits=Count('produits'))
    form = CategorieForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, "Catégorie ajoutée.")
        return redirect('monapp:admin_categories')
    return render(request, 'src/admin_categories.html', {'categories': categories, 'form': form})


@user_passes_test(est_staff, login_url='monapp:admin_login')
def admin_categorie_supprimer_vue(request, pk):
    categorie = get_object_or_404(Categorie, pk=pk)
    if request.method == 'POST':
        categorie.delete()
        messages.success(request, "Catégorie supprimée.")
        return redirect('monapp:admin_categories')
    return render(request, 'src/admin_confirmer_suppression.html', {'objet': categorie, 'type_objet': 'catégorie'})


@user_passes_test(est_staff, login_url='monapp:admin_login')
def admin_commandes_vue(request):
    commandes = Commande.objects.all()
    statut = request.GET.get('statut', '').strip()
    if statut:
        commandes = commandes.filter(statut=statut)
    return render(request, 'src/admin_commandes.html', {
        'commandes': commandes,
        'statut_choices': Commande.STATUT_CHOICES,
        'statut': statut,
    })


@user_passes_test(est_staff, login_url='monapp:admin_login')
def admin_commande_detail_vue(request, pk):
    commande = get_object_or_404(Commande, pk=pk)
    if request.method == 'POST':
        nouveau_statut = request.POST.get('statut')
        if nouveau_statut in dict(Commande.STATUT_CHOICES):
            commande.statut = nouveau_statut
            commande.save(update_fields=['statut', 'date_maj'])
            messages.success(request, f"Statut de la commande {commande.numero} mis à jour.")
        return redirect('monapp:admin_commande_detail', pk=pk)
    return render(request, 'src/admin_commande_detail.html', {
        'commande': commande,
        'statut_choices': Commande.STATUT_CHOICES,
    })
